package com.example.project.dao;

import com.example.project.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FlagDAO {

    public boolean createFlag(int courseId,int studentId,String type,String description){

        String sql="INSERT INTO flags(course_id,student_id,type,description) VALUES(?,?,?,?)";

        try(Connection c = DBConnection.getConnection();
            PreparedStatement ps = c.prepareStatement(sql)){

            ps.setInt(1,courseId);
            ps.setInt(2,studentId);
            ps.setString(3,type);
            ps.setString(4,description);

            return ps.executeUpdate()==1;

        }catch(Exception e){
            e.printStackTrace();
            return false;
        }
    }

    public List<Map<String,Object>> getFlagsByCourse(int courseId){

        List<Map<String,Object>> list=new ArrayList<>();

        String sql="SELECT student_id,type,description FROM flags WHERE course_id=?";

        try(Connection c=DBConnection.getConnection();
            PreparedStatement ps=c.prepareStatement(sql)){

            ps.setInt(1,courseId);

            ResultSet rs=ps.executeQuery();

            while(rs.next()){

                Map<String,Object> map=new HashMap<>();

                map.put("student",rs.getInt("student_id"));
                map.put("type",rs.getString("type"));
                map.put("description",rs.getString("description"));

                list.add(map);
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return list;
    }

    public List<Map<String,Object>> getFlagsByStudent(int studentId){

        List<Map<String,Object>> list=new ArrayList<>();

        String sql="SELECT type,description FROM flags WHERE student_id=?";

        try(Connection c=DBConnection.getConnection();
            PreparedStatement ps=c.prepareStatement(sql)){

            ps.setInt(1,studentId);

            ResultSet rs=ps.executeQuery();

            while(rs.next()){

                Map<String,Object> map=new HashMap<>();

                map.put("type",rs.getString("type"));
                map.put("description",rs.getString("description"));

                list.add(map);
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return list;
    }
}