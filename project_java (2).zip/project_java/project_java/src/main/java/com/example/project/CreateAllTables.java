package com.example.project;

import java.sql.Connection;
import java.sql.Statement;

public class CreateAllTables {
    public static void main(String[] args) {
        try {
            Connection conn = DBConnection.getConnection();
            Statement stmt = conn.createStatement();

            // Attendance table
            stmt.execute("CREATE TABLE IF NOT EXISTS attendance (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "student_id INT NOT NULL, " +
                    "course_id INT NOT NULL, " +
                    "attendance_date DATE NOT NULL, " +
                    "is_present BOOLEAN NOT NULL, " +
                    "FOREIGN KEY (student_id) REFERENCES users(user_id) ON DELETE CASCADE, " +
                    "FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE)");
            System.out.println("Attendance table created");

            // Grades table
            stmt.execute("CREATE TABLE IF NOT EXISTS grades (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "student_id INT NOT NULL, " +
                    "course_id INT NOT NULL, " +
                    "grade DOUBLE NOT NULL, " +
                    "UNIQUE KEY unique_student_course (student_id, course_id), " +
                    "FOREIGN KEY (student_id) REFERENCES users(user_id) ON DELETE CASCADE, " +
                    "FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE)");
            System.out.println("Grades table created");

            // Class sessions table
            stmt.execute("CREATE TABLE IF NOT EXISTS class_sessions (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "course_id INT NOT NULL, " +
                    "session_date DATE NOT NULL, " +
                    "topic_covered VARCHAR(200), " +
                    "total_students INT, " +
                    "FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE)");
            System.out.println("Class sessions table created");

            // Progress tracking table
            stmt.execute("CREATE TABLE IF NOT EXISTS progress_tracking (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "student_id INT NOT NULL, " +
                    "course_id INT NOT NULL, " +
                    "module_name VARCHAR(200) NOT NULL, " +
                    "status VARCHAR(50), " +
                    "progress_percentage INT, " +
                    "updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, " +
                    "UNIQUE KEY unique_student_course_module (student_id, course_id, module_name), " +
                    "FOREIGN KEY (student_id) REFERENCES users(user_id) ON DELETE CASCADE, " +
                    "FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE)");
            System.out.println("Progress tracking table created");

            // Study plans table
            stmt.execute("CREATE TABLE IF NOT EXISTS study_plans (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "student_id INT NOT NULL, " +
                    "course_id INT NOT NULL, " +
                    "task_description TEXT, " +
                    "due_date DATE, " +
                    "priority VARCHAR(50), " +
                    "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
                    "FOREIGN KEY (student_id) REFERENCES users(user_id) ON DELETE CASCADE, " +
                    "FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE)");
            System.out.println("Study plans table created");

            stmt.close();
            conn.close();
            System.out.println("\nAll tables created successfully!");
        } catch (Exception e) {
            System.out.println("Error (may be due to tables already existing): " + e.getMessage());
        }
    }
}