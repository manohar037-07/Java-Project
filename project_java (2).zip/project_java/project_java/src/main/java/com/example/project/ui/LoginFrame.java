package com.example.project.ui;

import com.example.project.dao.UserDAO;
import com.example.project.model.User;

import javax.swing.*;
import java.awt.*;

public class LoginFrame extends JFrame {

    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JButton btnLogin;

    public LoginFrame() {

    setTitle("Student Management System");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setSize(800,500);
    setLocationRelativeTo(null);

    // Background panel
    JPanel bgPanel = new JPanel(new GridBagLayout());
    bgPanel.setBackground(new Color(230,240,255));

    // Login card
    JPanel card = new JPanel();
    card.setLayout(new GridBagLayout());
    card.setPreferredSize(new Dimension(350,250));
    card.setBackground(Color.WHITE);
    card.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY,2));

    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(10,10,10,10);
    gbc.fill = GridBagConstraints.HORIZONTAL;

    // Title
    JLabel title = new JLabel("Login");
    title.setFont(new Font("Arial",Font.BOLD,24));
    title.setHorizontalAlignment(SwingConstants.CENTER);

    // Labels
    JLabel lblUser = new JLabel("Username:");
    JLabel lblPass = new JLabel("Password:");

    // Fields
    txtUsername = new JTextField();
    txtPassword = new JPasswordField();

    txtUsername.setPreferredSize(new Dimension(200,30));
    txtPassword.setPreferredSize(new Dimension(200,30));

    // Button
    btnLogin = new JButton("Login");
    btnLogin.setBackground(new Color(70,130,180));
    btnLogin.setForeground(Color.WHITE);
    btnLogin.setFocusPainted(false);

    // Layout
    gbc.gridx=0; gbc.gridy=0; gbc.gridwidth=2;
    card.add(title,gbc);

    gbc.gridwidth=1;
    gbc.gridy=1; gbc.gridx=0;
    card.add(lblUser,gbc);

    gbc.gridx=1;
    card.add(txtUsername,gbc);

    gbc.gridy=2; gbc.gridx=0;
    card.add(lblPass,gbc);

    gbc.gridx=1;
    card.add(txtPassword,gbc);

    gbc.gridy=3; gbc.gridx=0; gbc.gridwidth=2;
    card.add(btnLogin,gbc);

    bgPanel.add(card);
    add(bgPanel);

    btnLogin.addActionListener(e -> doLogin());
}

    private void doLogin() {

        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword()).trim();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this,"Enter username and password","Error",JOptionPane.ERROR_MESSAGE);
            return;
        }

        UserDAO dao = new UserDAO();
        User u = dao.authenticate(username,password);

        if (u == null) {
            JOptionPane.showMessageDialog(this,"Invalid credentials","Login Failed",JOptionPane.ERROR_MESSAGE);
            return;
        }

        JOptionPane.showMessageDialog(this,"Welcome "+u.getUsername()+" ("+u.getRole()+")");

        if ("ADMIN".equalsIgnoreCase(u.getRole())) {

            AdminDashboardFrame ad = new AdminDashboardFrame(u);
            ad.setVisible(true);

        } else if ("FACULTY".equalsIgnoreCase(u.getRole())) {

            FacultyDashboardFrame fd = new FacultyDashboardFrame(u);
            fd.setVisible(true);

        } else {

            StudentDashboardFrame sd = new StudentDashboardFrame(u);
            sd.setVisible(true);
        }

        this.dispose();
    }
}