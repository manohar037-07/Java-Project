package com.example.project;

import java.sql.Connection;
import java.sql.Statement;
import java.nio.file.Files;
import java.nio.file.Paths;

public class SetupDB {
    public static void main(String[] args) {
        try {
            Connection conn = DBConnection.getConnection();
            Statement stmt = conn.createStatement();

            // Create database and basic tables first
            stmt.execute("CREATE DATABASE IF NOT EXISTS schooldb");
            stmt.execute("USE schooldb");

            // Create tables in dependency order (without foreign keys first)
            stmt.execute("CREATE TABLE IF NOT EXISTS users (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(100) NOT NULL UNIQUE, password VARCHAR(255) NOT NULL, role ENUM('ADMIN','FACULTY','STUDENT') NOT NULL)");
            stmt.execute("CREATE TABLE IF NOT EXISTS departments (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(150) NOT NULL UNIQUE)");
            stmt.execute("CREATE TABLE IF NOT EXISTS subjects (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(150) NOT NULL, department_id INT)");
            stmt.execute("CREATE TABLE IF NOT EXISTS courses (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(150) NOT NULL, subject_id INT)");
            stmt.execute("CREATE TABLE IF NOT EXISTS faculty_courses (id INT AUTO_INCREMENT PRIMARY KEY, faculty_id INT NOT NULL, course_id INT NOT NULL, UNIQUE KEY uniq_faculty_course (faculty_id, course_id))");
            stmt.execute("CREATE TABLE IF NOT EXISTS student_courses (id INT AUTO_INCREMENT PRIMARY KEY, student_id INT NOT NULL, course_id INT NOT NULL, UNIQUE KEY uniq_student_course (student_id, course_id))");

            // Add foreign key constraints
            try { stmt.execute("ALTER TABLE subjects ADD CONSTRAINT fk_subjects_dept FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL"); } catch (Exception e) { /* ignore if already exists */ }
            try { stmt.execute("ALTER TABLE courses ADD CONSTRAINT fk_courses_subject FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE SET NULL"); } catch (Exception e) { /* ignore if already exists */ }
            try { stmt.execute("ALTER TABLE faculty_courses ADD CONSTRAINT fk_faculty_courses_user FOREIGN KEY (faculty_id) REFERENCES users(id) ON DELETE CASCADE"); } catch (Exception e) { /* ignore if already exists */ }
            try { stmt.execute("ALTER TABLE faculty_courses ADD CONSTRAINT fk_faculty_courses_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE"); } catch (Exception e) { /* ignore if already exists */ }
            try { stmt.execute("ALTER TABLE student_courses ADD CONSTRAINT fk_student_courses_user FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE"); } catch (Exception e) { /* ignore if already exists */ }
            try { stmt.execute("ALTER TABLE student_courses ADD CONSTRAINT fk_student_courses_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE"); } catch (Exception e) { /* ignore if already exists */ }

            // Execute data.sql
            String dataSql = new String(Files.readAllBytes(Paths.get("sql/data.sql")));
            String[] dataStatements = dataSql.split(";");

            for (String sql : dataStatements) {
                sql = sql.trim();
                if (!sql.isEmpty() && !sql.startsWith("--")) {
                    System.out.println("Executing data: " + sql.substring(0, Math.min(50, sql.length())) + "...");
                    stmt.execute(sql);
                }
            }

            System.out.println("Database setup completed successfully!");
            stmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}