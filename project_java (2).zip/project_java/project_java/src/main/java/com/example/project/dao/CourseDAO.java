package com.example.project.dao;

import com.example.project.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class CourseDAO {
    
    public boolean createCourse(String name, Integer deptId) {
        // 'name' badulu 'course_name', 'subject_id' badulu 'dept_id'
        String sql = "INSERT INTO courses (course_name, dept_id) VALUES (?, ?)";
        try (Connection c = DBConnection.getConnection(); 
             PreparedStatement ps = c.prepareStatement(sql)) {
            
            ps.setString(1, name);
            if (deptId == null) {
                ps.setNull(2, java.sql.Types.INTEGER); 
            } else {
                ps.setInt(2, deptId);
            }
            return ps.executeUpdate() == 1;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<String> listCourses() {
        List<String> list = new ArrayList<>();
        // 'id' badulu 'course_id', 'name' badulu 'course_name'
        String sql = "SELECT course_id, course_name FROM courses";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(rs.getInt("course_id") + " - " + rs.getString("course_name"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public boolean deleteCourse(int id) {
        try (Connection con = DBConnection.getConnection()) {
            // 'id' badulu 'course_id'
            String sql = "DELETE FROM courses WHERE course_id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}