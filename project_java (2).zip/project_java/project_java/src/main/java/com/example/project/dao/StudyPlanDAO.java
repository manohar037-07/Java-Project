package com.example.project.dao;

import com.example.project.DBConnection;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StudyPlanDAO {
    public boolean addTask(int studentId, int courseId, String taskDescription, Date dueDate, String priority) {
        String sql = "INSERT INTO study_plans (student_id, course_id, task_description, due_date, priority, completed) VALUES (?, ?, ?, ?, ?, FALSE)";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ps.setInt(2, courseId);
            ps.setString(3, taskDescription);
            ps.setDate(4, dueDate);
            ps.setString(5, priority);
            return ps.executeUpdate() == 1;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean markTaskCompleted(int taskId) {
        String sql = "UPDATE study_plans SET completed = TRUE WHERE plan_id = ?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, taskId);
            return ps.executeUpdate() == 1;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Map<String, Object>> getStudentTasks(int studentId, int courseId) {
        List<Map<String, Object>> list = new ArrayList<>();
        String sql = "SELECT plan_id, task_description, due_date, priority, completed FROM study_plans WHERE student_id = ? AND course_id = ? ORDER BY due_date ASC";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ps.setInt(2, courseId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Map<String, Object> m = new HashMap<>();
                m.put("id", rs.getInt("plan_id"));
                m.put("description", rs.getString("task_description"));
                m.put("dueDate", rs.getDate("due_date"));
                m.put("priority", rs.getString("priority"));
                m.put("completed", rs.getBoolean("completed"));
                list.add(m);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public int getPendingTaskCount(int studentId, int courseId) {
        String sql = "SELECT COUNT(*) AS count FROM study_plans WHERE student_id = ? AND course_id = ? AND completed = FALSE";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ps.setInt(2, courseId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("count");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
}
