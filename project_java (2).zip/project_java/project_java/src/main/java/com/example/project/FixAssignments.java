package com.example.project;

import java.sql.Connection;
import java.sql.Statement;

public class FixAssignments {
    public static void main(String[] args) {
        try {
            Connection conn = DBConnection.getConnection();
            Statement stmt = conn.createStatement();

            // Remove Ravi's current assignment (course 1)
            stmt.execute("DELETE FROM faculty_courses WHERE faculty_id = 4 AND course_id = 1");
            System.out.println("Removed Ravi from Java course");

            // Assign Ravi to C++ (course 2)
            stmt.execute("INSERT INTO faculty_courses (faculty_id, course_id) VALUES (4, 2)");
            System.out.println("Assigned Ravi to C++ course");

            stmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}