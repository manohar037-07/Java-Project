package com.example.project.ui;

import com.example.project.dao.AllocationDAO;
import com.example.project.dao.CourseDAO;
import com.example.project.dao.DepartmentDAO;
import com.example.project.dao.UserDAO;
import com.example.project.model.User;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class AdminDashboardFrame extends JFrame {

    private UserDAO userDAO = new UserDAO();
    private DepartmentDAO deptDAO = new DepartmentDAO();
    private CourseDAO courseDAO = new CourseDAO();
    private AllocationDAO allocDAO = new AllocationDAO();

    public AdminDashboardFrame(User admin) {

        setTitle("Admin Dashboard - " + admin.getUsername());
        setSize(900,600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JTabbedPane tabs = new JTabbedPane();

        tabs.addTab("Users", buildUsersPanel());
        tabs.addTab("Departments", buildDepartmentsPanel());
        tabs.addTab("Courses", buildCoursesPanel());
        tabs.addTab("Allocations", buildAllocationsPanel());

        JButton btnLogout = new JButton("Logout");

        btnLogout.addActionListener(e -> {
            dispose();
            new LoginFrame().setVisible(true);
        });

        add(tabs, BorderLayout.CENTER);
        add(btnLogout, BorderLayout.SOUTH);
    }

    // ================= USERS =================

    private JPanel buildUsersPanel() {

        JPanel panel = new JPanel(new BorderLayout());

        JPanel top = new JPanel(new GridLayout(4,2,10,10));

        JTextField txtUser = new JTextField();
        JTextField txtPass = new JTextField();

        JComboBox<String> cmbRole =
                new JComboBox<>(new String[]{"ADMIN","FACULTY","STUDENT"});

        JButton btnCreate = new JButton("Create User");

        top.add(new JLabel("Username"));
        top.add(txtUser);

        top.add(new JLabel("Password"));
        top.add(txtPass);

        top.add(new JLabel("Role"));
        top.add(cmbRole);

        top.add(new JLabel());
        top.add(btnCreate);

        panel.add(top, BorderLayout.NORTH);

        DefaultListModel<String> model = new DefaultListModel<>();
        JList<String> list = new JList<>(model);

        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.add(new JScrollPane(list), BorderLayout.CENTER);

        JButton btnDelete = new JButton("Delete Selected User");
        JPanel bottomPanel = new JPanel();
        bottomPanel.add(btnDelete);
        centerPanel.add(bottomPanel, BorderLayout.SOUTH);

        panel.add(centerPanel, BorderLayout.CENTER);

        btnCreate.addActionListener(e -> {

            String u = txtUser.getText().trim();
            String p = txtPass.getText().trim();
            String r = (String)cmbRole.getSelectedItem();

            if(u.isEmpty() || p.isEmpty()){
                JOptionPane.showMessageDialog(this,"Username and Password are required");
                return;
            }

            if(userDAO.createUser(u,p,r)){
                JOptionPane.showMessageDialog(this,"User Created");
                txtUser.setText("");
                txtPass.setText("");
                refreshUsers(model);
                list.revalidate();
                list.repaint();
            } else {
                JOptionPane.showMessageDialog(this,"User creation failed");
            }
        });

        btnDelete.addActionListener(e -> {
            String selected = list.getSelectedValue();
            if(selected == null){
                JOptionPane.showMessageDialog(this,"Please select a user to delete");
                return;
            }

            String[] parts = selected.split(" - ");
            if(parts.length < 2){
                JOptionPane.showMessageDialog(this,"Invalid selection path");
                return;
            }

            int userId = Integer.parseInt(parts[0].split(":")[1].trim());
            if(userDAO.deleteUser(userId)){
                JOptionPane.showMessageDialog(this,"User Deleted");
                refreshUsers(model);
                list.revalidate();
                list.repaint();
            } else {
                JOptionPane.showMessageDialog(this,"Failed to delete user");
            }
        });

        refreshUsers(model);

        return panel;
    }

    private void refreshUsers(DefaultListModel<String> model){

        model.clear();

        for(String role : new String[]{"ADMIN","FACULTY","STUDENT"}){

            List<User> users = userDAO.listUsersByRole(role);

            for(User u : users)
                model.addElement(role+" : "+u.getId()+" - "+u.getUsername());
        }
    }

    // ================= DEPARTMENTS =================

    private JPanel buildDepartmentsPanel(){

        JPanel panel = new JPanel(new BorderLayout());

        JPanel top = new JPanel(new GridLayout(1,2,10,10));

        JTextField txtDept = new JTextField();
        JButton btnAdd = new JButton("Add Department");

        top.add(txtDept);
        top.add(btnAdd);

        panel.add(top,BorderLayout.NORTH);

        DefaultListModel<String> model = new DefaultListModel<>();
        JList<String> list = new JList<>(model);

        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.add(new JScrollPane(list), BorderLayout.CENTER);

        JButton btnDelete = new JButton("Delete Selected Department");
        JPanel bottomPanel = new JPanel();
        bottomPanel.add(btnDelete);
        centerPanel.add(bottomPanel, BorderLayout.SOUTH);

        panel.add(centerPanel,BorderLayout.CENTER);

        btnAdd.addActionListener(e -> {
            String deptName = txtDept.getText().trim();
            if(deptName.isEmpty()){
                JOptionPane.showMessageDialog(this,"Department name is required");
                return;
            }

            if(deptDAO.createDepartment(deptName)){
                JOptionPane.showMessageDialog(this,"Department Added");
                txtDept.setText("");
                refreshDepartments(model);
                list.revalidate();
                list.repaint();
            } else {
                JOptionPane.showMessageDialog(this,"Failed to add department");
            }
        });

        btnDelete.addActionListener(e -> {
            String selected = list.getSelectedValue();
            if(selected == null){
                JOptionPane.showMessageDialog(this,"Please select a department to delete");
                return;
            }

            if(deptDAO.deleteDepartment(selected)){
                JOptionPane.showMessageDialog(this,"Department Deleted");
                refreshDepartments(model);
                list.revalidate();
                list.repaint();
            } else {
                JOptionPane.showMessageDialog(this,"Failed to delete department");
            }
        });

        refreshDepartments(model);

        return panel;
    }

    private void refreshDepartments(DefaultListModel<String> model){

        model.clear();

        for(String d : deptDAO.listDepartments())
            model.addElement(d);
    }

    // ================= COURSES =================

    private JPanel buildCoursesPanel(){

        JPanel panel = new JPanel(new BorderLayout());

        JTextField txtCourse = new JTextField();
        JButton btnAdd = new JButton("Add Course");

        JPanel top = new JPanel(new GridLayout(1,2,10,10));

        top.add(txtCourse);
        top.add(btnAdd);

        panel.add(top,BorderLayout.NORTH);

        DefaultListModel<String> model = new DefaultListModel<>();
        JList<String> list = new JList<>(model);

        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.add(new JScrollPane(list), BorderLayout.CENTER);

        JButton btnDelete = new JButton("Delete Selected Course");
        JPanel bottomPanel = new JPanel();
        bottomPanel.add(btnDelete);
        centerPanel.add(bottomPanel, BorderLayout.SOUTH);

        panel.add(centerPanel,BorderLayout.CENTER);

        btnAdd.addActionListener(e -> {
            String courseName = txtCourse.getText().trim();
            if(courseName.isEmpty()){
                JOptionPane.showMessageDialog(this,"Course name is required");
                return;
            }

            if(courseDAO.createCourse(courseName,null)){
                JOptionPane.showMessageDialog(this,"Course Added");
                txtCourse.setText("");
                refreshCourses(model);
                list.revalidate();
                list.repaint();
            } else {
                JOptionPane.showMessageDialog(this,"Failed to add course");
            }
        });

        btnDelete.addActionListener(e -> {
            String selected = list.getSelectedValue();
            if(selected == null){
                JOptionPane.showMessageDialog(this,"Please select a course to delete");
                return;
            }

            int courseId = Integer.parseInt(selected.split(" - ")[0]);
            if(courseDAO.deleteCourse(courseId)){
                JOptionPane.showMessageDialog(this,"Course Deleted");
                refreshCourses(model);
                list.revalidate();
                list.repaint();
            } else {
                JOptionPane.showMessageDialog(this,"Failed to delete course");
            }
        });

        refreshCourses(model);

        return panel;
    }

    private void refreshCourses(DefaultListModel<String> model){

        model.clear();

        for(String c : courseDAO.listCourses())
            model.addElement(c);
    }

    // ================= ALLOCATIONS =================

   private JPanel buildAllocationsPanel(){


JPanel panel = new JPanel(new BorderLayout());

JLabel title = new JLabel("Course Allocation",SwingConstants.CENTER);
title.setFont(new Font("Arial",Font.BOLD,20));
panel.add(title,BorderLayout.NORTH);

JPanel form = new JPanel();
form.setLayout(new GridLayout(4,2,10,10));
form.setBorder(BorderFactory.createEmptyBorder(40,200,40,200));

JTextField txtFacultyId = new JTextField();
JTextField txtStudentId = new JTextField();
JTextField txtCourseId = new JTextField();

JButton btnAssign = new JButton("Assign Course");

form.add(new JLabel("Faculty ID"));
form.add(txtFacultyId);

form.add(new JLabel("Student ID"));
form.add(txtStudentId);

form.add(new JLabel("Course ID"));
form.add(txtCourseId);

form.add(new JLabel(""));
form.add(btnAssign);

panel.add(form,BorderLayout.CENTER);

// Display current allocations
DefaultListModel<String> model = new DefaultListModel<>();
JList<String> list = new JList<>(model);

JPanel centerPanel = new JPanel(new BorderLayout());
centerPanel.add(new JScrollPane(list), BorderLayout.CENTER);

JButton btnDelete = new JButton("Delete Selected Allocation");
JPanel bottomPanel = new JPanel();
bottomPanel.add(btnDelete);
centerPanel.add(bottomPanel, BorderLayout.SOUTH);

panel.add(centerPanel, BorderLayout.SOUTH);

btnAssign.addActionListener(e -> {

    try{

        String facultyIdStr = txtFacultyId.getText().trim();
        String studentIdStr = txtStudentId.getText().trim();
        String courseIdStr = txtCourseId.getText().trim();

        int courseId = Integer.parseInt(courseIdStr);

        if(!facultyIdStr.isEmpty()){
            int facultyId = Integer.parseInt(facultyIdStr);
            allocDAO.assignCourseToFaculty(facultyId,courseId);
        }

        if(!studentIdStr.isEmpty()){
            int studentId = Integer.parseInt(studentIdStr);
            allocDAO.assignCourseToStudent(studentId,courseId);
        }

        JOptionPane.showMessageDialog(this,"Course Assigned");
        refreshAllocations(model);

    }catch(Exception ex){
        JOptionPane.showMessageDialog(this,"Assignment Failed: " + ex.getMessage());
    }

});

btnDelete.addActionListener(e -> {
    String selected = list.getSelectedValue();
    if(selected == null){
        JOptionPane.showMessageDialog(this,"Please select an allocation to delete");
        return;
    }

    // Parse the selected allocation
    try {
        if(selected.startsWith("Faculty:")){
            String[] parts = selected.split(" - ");
            int facultyId = Integer.parseInt(parts[1]);
            int courseId = Integer.parseInt(parts[3]);
            if(allocDAO.removeFacultyCourseAssignment(facultyId, courseId)){
                JOptionPane.showMessageDialog(this,"Faculty allocation deleted");
                refreshAllocations(model);
            }
        } else if(selected.startsWith("Student:")){
            String[] parts = selected.split(" - ");
            int studentId = Integer.parseInt(parts[1]);
            int courseId = Integer.parseInt(parts[3]);
            if(allocDAO.removeStudentCourseAssignment(studentId, courseId)){
                JOptionPane.showMessageDialog(this,"Student allocation deleted");
                refreshAllocations(model);
            }
        }
    } catch(Exception ex){
        JOptionPane.showMessageDialog(this,"Failed to delete allocation: " + ex.getMessage());
    }
});

refreshAllocations(model);

return panel;

}

private void refreshAllocations(DefaultListModel<String> model){

    model.clear();

    // Add faculty allocations
    List<String> facultyAllocations = allocDAO.listAllFacultyAllocations();
    for(String alloc : facultyAllocations){
        model.addElement(alloc);
    }

    // Add student allocations
    List<String> studentAllocations = allocDAO.listAllStudentAllocations();
    for(String alloc : studentAllocations){
        model.addElement(alloc);
    }
}
}
