package com.example.project;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class CheckDB {
    public static void main(String[] args) {
        try {
            Connection conn = DBConnection.getConnection();
            Statement stmt = conn.createStatement();

            // Check what tables exist
            ResultSet rs = stmt.executeQuery("SHOW TABLES");
            System.out.println("Tables in schooldb:");
            while (rs.next()) {
                System.out.println("- " + rs.getString(1));
            }

            // Check faculty_courses table structure
            rs = stmt.executeQuery("DESCRIBE faculty_courses");
            System.out.println("\nFaculty_courses table structure:");
            while (rs.next()) {
                System.out.println(rs.getString(1) + " - " + rs.getString(2));
            }

            // Check users data
            rs = stmt.executeQuery("SELECT user_id, username, role FROM users");
            System.out.println("\nUsers in database:");
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("user_id") + ", Username: " + rs.getString("username") + ", Role: " + rs.getString("role"));
            }

            // Check courses
            rs = stmt.executeQuery("SELECT course_id, course_name FROM courses");
            System.out.println("\nCourses in database:");
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("course_id") + ", Name: " + rs.getString("course_name"));
            }

            // Check topics table structure
            rs = stmt.executeQuery("DESCRIBE topics");
            System.out.println("\nTopics table structure:");
            while (rs.next()) {
                System.out.println(rs.getString(1) + " - " + rs.getString(2));
            }

            // Check study_plans table structure
            rs = stmt.executeQuery("DESCRIBE study_plans");
            System.out.println("\nStudy_plans table structure:");
            while (rs.next()) {
                System.out.println(rs.getString(1) + " - " + rs.getString(2));
            }

            stmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}