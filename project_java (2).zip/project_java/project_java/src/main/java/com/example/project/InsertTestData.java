package com.example.project;

import java.sql.Connection;
import java.sql.Statement;

public class InsertTestData {
    public static void main(String[] args) {
        try {
            Connection conn = DBConnection.getConnection();
            Statement stmt = conn.createStatement();

            // Insert test assignment
            stmt.execute("INSERT INTO faculty_courses (faculty_id, course_id) VALUES (2, 1)");
            System.out.println("Test assignment inserted for faculty ID 2 to course ID 1");

            stmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}