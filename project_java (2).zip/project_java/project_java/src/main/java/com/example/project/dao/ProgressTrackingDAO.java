package com.example.project.dao;

import com.example.project.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProgressTrackingDAO {
    public boolean updateModuleProgress(int studentId, int courseId, String moduleName, String status, int progressPercentage) {
        String sql = "INSERT INTO progress_tracking (student_id, course_id, module_name, status, progress_percentage) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE status = ?, progress_percentage = ?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ps.setInt(2, courseId);
            ps.setString(3, moduleName);
            ps.setString(4, status);
            ps.setInt(5, progressPercentage);
            ps.setString(6, status);
            ps.setInt(7, progressPercentage);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Map<String, Object>> getModuleProgress(int studentId, int courseId) {
        List<Map<String, Object>> list = new ArrayList<>();
        String sql = "SELECT id, module_name, status, progress_percentage, updated_at FROM progress_tracking WHERE student_id = ? AND course_id = ? ORDER BY module_name ASC";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ps.setInt(2, courseId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Map<String, Object> m = new HashMap<>();
                m.put("id", rs.getInt("id"));
                m.put("name", rs.getString("module_name"));
                m.put("status", rs.getString("status"));
                m.put("percentage", rs.getInt("progress_percentage"));
                m.put("updated", rs.getTimestamp("updated_at"));
                list.add(m);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public double getOverallCourseProgress(int studentId, int courseId) {
        String sql = "SELECT AVG(progress_percentage) AS avg_progress FROM progress_tracking WHERE student_id = ? AND course_id = ?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ps.setInt(2, courseId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                double avg = rs.getDouble("avg_progress");
                return Double.isNaN(avg) ? 0 : avg;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
}
