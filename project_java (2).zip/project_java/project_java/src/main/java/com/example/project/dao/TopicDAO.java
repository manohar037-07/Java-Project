package com.example.project.dao;

import com.example.project.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TopicDAO {

    public boolean addTopic(int courseId, String name, String desc) {
        String sql = "INSERT INTO topics (course_id, topic_name, description) VALUES (?, ?, ?)";
        try (Connection c = DBConnection.getConnection(); 
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            ps.setString(2, name);
            ps.setString(3, desc);
            return ps.executeUpdate() == 1;
        } catch (Exception e) { e.printStackTrace(); return false; }
    }

    public List<Map<String, Object>> getTopicsByCourse(int courseId) {
        List<Map<String, Object>> list = new ArrayList<>();
        String sql = "SELECT topic_name, description FROM topics WHERE course_id = ?";
        try (Connection c = DBConnection.getConnection(); 
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Map<String, Object> map = new HashMap<>();
                map.put("name", rs.getString("topic_name"));
                map.put("description", rs.getString("description"));
                list.add(map);
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }
}