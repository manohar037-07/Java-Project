package com.example.project;

import java.sql.Connection;
import java.sql.Statement;

public class CreateTopicsTable {
    public static void main(String[] args) {
        try {
            Connection conn = DBConnection.getConnection();
            Statement stmt = conn.createStatement();

            // Create topics table
            stmt.execute("CREATE TABLE IF NOT EXISTS topics (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "course_id INT NOT NULL, " +
                    "topic_name VARCHAR(200) NOT NULL, " +
                    "description TEXT, " +
                    "FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE)");
            System.out.println("Topics table created successfully");

            stmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}