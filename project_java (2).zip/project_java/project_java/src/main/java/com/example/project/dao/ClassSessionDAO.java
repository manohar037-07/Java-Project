package com.example.project.dao;

import com.example.project.DBConnection;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ClassSessionDAO {
    public boolean recordSession(int courseId, Date sessionDate, String topicCovered, int totalStudents) {
        String sql = "INSERT INTO class_sessions (course_id, session_date, topic_covered, total_students) VALUES (?, ?, ?, ?)";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            ps.setDate(2, sessionDate);
            ps.setString(3, topicCovered);
            ps.setInt(4, totalStudents);
            return ps.executeUpdate() == 1;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Map<String, Object>> getSessionsByCourse(int courseId) {
        List<Map<String, Object>> list = new ArrayList<>();
        String sql = "SELECT id, session_date, topic_covered, total_students FROM class_sessions WHERE course_id = ? ORDER BY session_date DESC";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Map<String, Object> m = new HashMap<>();
                m.put("id", rs.getInt("id"));
                m.put("date", rs.getDate("session_date"));
                m.put("topic", rs.getString("topic_covered"));
                m.put("students", rs.getInt("total_students"));
                list.add(m);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public double getAverageAttendanceInCourse(int courseId) {
        String sql = "SELECT AVG(total_students) AS avg_attendance FROM class_sessions WHERE course_id = ?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getDouble("avg_attendance");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
}
