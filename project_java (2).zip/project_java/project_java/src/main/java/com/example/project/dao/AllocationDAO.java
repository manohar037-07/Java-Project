package com.example.project.dao;

import com.example.project.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class AllocationDAO {
   public boolean assignCourseToFaculty(int facultyId, int courseId) {

    String sql = "INSERT INTO faculty_courses (faculty_id, course_id) VALUES (?, ?)";

    try (Connection c = DBConnection.getConnection();
         PreparedStatement ps = c.prepareStatement(sql)) {

        ps.setInt(1, facultyId);
        ps.setInt(2, courseId);

        return ps.executeUpdate() == 1;

    } catch (Exception e) {
        e.printStackTrace();
        return false;
    }
}
    public boolean assignCourseToStudent(int studentId, int courseId) {
        String sql = "INSERT INTO student_courses (student_id, course_id) VALUES (?, ?)";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ps.setInt(2, courseId);
            return ps.executeUpdate() == 1;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<String> listCoursesByFaculty(int facultyId) {
        List<String> list = new ArrayList<>();

        String sql = "SELECT c.course_id, c.course_name FROM courses c JOIN faculty_courses fc ON c.course_id = fc.course_id WHERE fc.faculty_id = ?";

        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setInt(1, facultyId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                int id = rs.getInt("course_id");
                String name = rs.getString("course_name");
                String courseStr = id + " - " + name;
                list.add(courseStr);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public List<String> listCoursesByStudent(int studentId) {
        List<String> list = new ArrayList<>();
        String sql = "SELECT c.course_id, c.course_name FROM courses c JOIN student_courses sc ON c.course_id = sc.course_id WHERE sc.student_id = ?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("course_id");
                String name = rs.getString("course_name");
                list.add(id + " - " + name);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public boolean removeFacultyCourseAssignment(int facultyId, int courseId) {
        String sql = "DELETE FROM faculty_courses WHERE faculty_id = ? AND course_id = ?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, facultyId);
            ps.setInt(2, courseId);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean removeStudentCourseAssignment(int studentId, int courseId) {
        String sql = "DELETE FROM student_courses WHERE student_id = ? AND course_id = ?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ps.setInt(2, courseId);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<String> listAllFacultyAllocations() {
        List<String> list = new ArrayList<>();
        String sql = "SELECT fc.faculty_id, u.username, fc.course_id, c.course_name FROM faculty_courses fc JOIN users u ON fc.faculty_id = u.user_id JOIN courses c ON fc.course_id = c.course_id";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add("Faculty: " + rs.getInt("faculty_id") + " - " + rs.getString("username") + " - Course: " + rs.getInt("course_id") + " - " + rs.getString("course_name"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<String> listAllStudentAllocations() {
        List<String> list = new ArrayList<>();
        String sql = "SELECT sc.student_id, u.username, sc.course_id, c.course_name FROM student_courses sc JOIN users u ON sc.student_id = u.user_id JOIN courses c ON sc.course_id = c.course_id";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add("Student: " + rs.getInt("student_id") + " - " + rs.getString("username") + " - Course: " + rs.getInt("course_id") + " - " + rs.getString("course_name"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
