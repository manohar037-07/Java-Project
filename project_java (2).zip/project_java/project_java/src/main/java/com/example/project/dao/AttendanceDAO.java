package com.example.project.dao;

import com.example.project.DBConnection;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AttendanceDAO {
    public boolean recordAttendance(int studentId, int courseId, Date date, boolean isPresent) {
        String sql = "INSERT INTO attendance (student_id, course_id, attendance_date, is_present) VALUES (?, ?, ?, ?)";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ps.setInt(2, courseId);
            ps.setDate(3, date);
            ps.setBoolean(4, isPresent);
            return ps.executeUpdate() == 1;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public double getAttendancePercentage(int studentId, int courseId) {
        String sql = "SELECT COUNT(*) AS total, SUM(CASE WHEN is_present = TRUE THEN 1 ELSE 0 END) AS present FROM attendance WHERE student_id = ? AND course_id = ?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ps.setInt(2, courseId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                int total = rs.getInt("total");
                int present = rs.getInt("present");
                return total > 0 ? (100.0 * present / total) : 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public List<Map<String, Object>> getStudentAttendance(int studentId, int courseId) {
        List<Map<String, Object>> list = new ArrayList<>();
        String sql = "SELECT attendance_date, is_present FROM attendance WHERE student_id = ? AND course_id = ?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ps.setInt(2, courseId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Map<String, Object> m = new HashMap<>();
                m.put("date", rs.getDate("attendance_date"));
                m.put("present", rs.getBoolean("is_present"));
                list.add(m);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
