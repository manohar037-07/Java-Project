package com.example.project.ui;

import com.example.project.dao.*;
import com.example.project.DBConnection;
import com.example.project.model.User;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class FacultyDashboardFrame extends JFrame {

    private User faculty;

    private AllocationDAO allocDAO = new AllocationDAO();
    private TopicDAO topicDAO = new TopicDAO();
    private AttendanceDAO attendanceDAO = new AttendanceDAO();
    private GradeDAO gradeDAO = new GradeDAO();
    private FlagDAO flagDAO = new FlagDAO();
    private ProgressTrackingDAO progressDAO = new ProgressTrackingDAO();
    private StudyPlanDAO studyPlanDAO = new StudyPlanDAO();

    public FacultyDashboardFrame(User faculty) {

        this.faculty = faculty;

        setTitle("Faculty Dashboard - " + faculty.getUsername());
        setSize(1200, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JTabbedPane tabs = new JTabbedPane();

        tabs.addTab("My Courses", buildCoursesPanel());
        tabs.addTab("Syllabus Management", buildSyllabusPanel());
        tabs.addTab("Student Tracking", buildTrackingPanel());
        tabs.addTab("Monitor Progress", buildProgressMonitoringPanel());
        tabs.addTab("Flagging System", buildFlagPanel());

        add(tabs, BorderLayout.CENTER);
        setVisible(true);
    }

    // ================= COURSES =================

    private JPanel buildCoursesPanel(){

        JPanel p = new JPanel(new BorderLayout());
        p.setBorder(BorderFactory.createTitledBorder("Assigned Courses"));

        DefaultListModel<String> model = new DefaultListModel<>();
        JList<String> list = new JList<>(model);
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.setFont(new Font("Arial", Font.PLAIN, 14));

        JScrollPane scrollPane = new JScrollPane(list);
        scrollPane.setPreferredSize(new Dimension(400, 300));

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(new JLabel("Your Assigned Courses:"), BorderLayout.WEST);
        
        JButton btnRefresh = new JButton("Refresh");
        btnRefresh.addActionListener(e -> refreshCoursesList(model));
        topPanel.add(btnRefresh, BorderLayout.EAST);

        p.add(topPanel, BorderLayout.NORTH);
        p.add(scrollPane, BorderLayout.CENTER);

        refreshCoursesList(model);

        return p;
    }

    private void refreshCoursesList(DefaultListModel<String> model) {
        model.clear();
        List<String> courses = allocDAO.listCoursesByFaculty(faculty.getId());

        if(courses == null || courses.isEmpty()) {
            model.addElement("No courses assigned");
        } else {
            for(String c : courses) {
                model.addElement(c);
            }
        }
    }

    // ================= SYLLABUS =================

    private JPanel buildSyllabusPanel() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBorder(BorderFactory.createTitledBorder("Manage Course Syllabus"));

        JPanel top = new JPanel(new GridLayout(4, 2, 6, 6));
        top.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JComboBox<String> cmbCourse = new JComboBox<>();
        JTextField txtTopicName = new JTextField();
        JTextField txtTopicDescription = new JTextField();
        JButton btnAdd = new JButton("Add Topic");

        top.add(new JLabel("Select Course:"));
        top.add(cmbCourse);
        top.add(new JLabel("Topic Name:"));
        top.add(txtTopicName);
        top.add(new JLabel("Topic Description:"));
        top.add(txtTopicDescription);
        top.add(new JLabel(""));
        top.add(btnAdd);

        p.add(top, BorderLayout.NORTH);

        DefaultListModel<String> topicListModel = new DefaultListModel<>();
        JList<String> topicList = new JList<>(topicListModel);
        topicList.setFont(new Font("Arial", Font.PLAIN, 12));
        topicList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(topicList);
        scrollPane.setPreferredSize(new Dimension(400, 300));

        p.add(scrollPane, BorderLayout.CENTER);

        List<String> courses = allocDAO.listCoursesByFaculty(faculty.getId());

        if(courses != null && !courses.isEmpty()) {
            for(String c : courses) {
                cmbCourse.addItem(c);
            }

            cmbCourse.addActionListener(e -> {
                String selectedCourse = (String)cmbCourse.getSelectedItem();
                if(selectedCourse != null) {
                    try {
                        int courseId = extractCourseId(selectedCourse);
                        refreshTopics(topicListModel, courseId);
                    } catch(Exception ex) {
                        JOptionPane.showMessageDialog(this, "Error loading topics");
                    }
                }
            });

            btnAdd.addActionListener(e -> {
                String selectedCourse = (String)cmbCourse.getSelectedItem();
                if(selectedCourse == null) {
                    JOptionPane.showMessageDialog(this, "Please select a course");
                    return;
                }

                String topicName = txtTopicName.getText().trim();
                String topicDesc = txtTopicDescription.getText().trim();

                if(topicName.isEmpty() || topicDesc.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Please fill in all fields");
                    return;
                }

                try {
                    int courseId = extractCourseId(selectedCourse);
                    if(topicDAO.addTopic(courseId, topicName, topicDesc)) {
                        JOptionPane.showMessageDialog(this, "Topic added successfully");
                        txtTopicName.setText("");
                        txtTopicDescription.setText("");
                        refreshTopics(topicListModel, courseId);
                    } else {
                        JOptionPane.showMessageDialog(this, "Failed to add topic");
                    }
                } catch(Exception ex) {
                    JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
                }
            });

            if(cmbCourse.getItemCount() > 0) {
                cmbCourse.setSelectedIndex(0);
                String selectedCourse = (String)cmbCourse.getSelectedItem();
                if(selectedCourse != null) {
                    try {
                        int courseId = extractCourseId(selectedCourse);
                        refreshTopics(topicListModel, courseId);
                    } catch(Exception ex) {
                        ex.printStackTrace();
                    }
                }
            }
        } else {
            topicListModel.addElement("No courses assigned to you");
            cmbCourse.setEnabled(false);
            txtTopicName.setEnabled(false);
            txtTopicDescription.setEnabled(false);
            btnAdd.setEnabled(false);
        }

        return p;
    }

    private void refreshTopics(DefaultListModel<String> model, int courseId) {
        model.clear();
        List<Map<String, Object>> topics = topicDAO.getTopicsByCourse(courseId);
        
        if(topics == null || topics.isEmpty()) {
            model.addElement("No topics added yet");
        } else {
            for(Map<String, Object> t : topics) {
                String topicName = (String)t.get("name");
                String topicDesc = (String)t.get("description");
                model.addElement(topicName + " - " + topicDesc);
            }
        }
    }

    private int extractCourseId(String courseStr) {
        return Integer.parseInt(courseStr.split(" - ")[0].trim());
    }

    // ================= STUDENT TRACKING =================

    private JPanel buildTrackingPanel(){

        JPanel p = new JPanel(new BorderLayout());
        p.setBorder(BorderFactory.createTitledBorder("Track Student Progress"));

        JPanel top = new JPanel(new GridLayout(3, 2, 6, 6));
        top.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JComboBox<String> cmbCourse = new JComboBox<>();
        JTextField txtStudentId = new JTextField();

        JButton btnAttendance = new JButton("View Attendance %");
        JButton btnGrades = new JButton("View Grades");

        top.add(new JLabel("Select Course:"));
        top.add(cmbCourse);

        top.add(new JLabel("Student ID:"));
        top.add(txtStudentId);

        top.add(new JLabel(""));
        top.add(new JLabel(""));

        p.add(top, BorderLayout.NORTH);

        JPanel center = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        center.add(btnAttendance);
        center.add(btnGrades);

        p.add(center, BorderLayout.CENTER);

        List<String> courses = allocDAO.listCoursesByFaculty(faculty.getId());

        if(courses != null && !courses.isEmpty()) {
            for(String c : courses){
                cmbCourse.addItem(c);
            }
        } else {
            cmbCourse.addItem("No courses assigned");
            cmbCourse.setEnabled(false);
            txtStudentId.setEnabled(false);
            btnAttendance.setEnabled(false);
            btnGrades.setEnabled(false);
        }

        btnAttendance.addActionListener(e -> {
            try{
                String studentIdStr = txtStudentId.getText().trim();
                if(studentIdStr.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Please enter Student ID");
                    return;
                }

                int studentId = Integer.parseInt(studentIdStr);
                String course = (String)cmbCourse.getSelectedItem();
                int courseId = extractCourseId(course);

                double perc = attendanceDAO.getAttendancePercentage(studentId, courseId);

                JOptionPane.showMessageDialog(this, "Attendance : " + String.format("%.2f", perc) + " %");

            }catch(NumberFormatException ex){
                JOptionPane.showMessageDialog(this, "Invalid Student ID");
            }catch(Exception ex){
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        btnGrades.addActionListener(e -> {
            try{
                String studentIdStr = txtStudentId.getText().trim();
                if(studentIdStr.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Please enter Student ID");
                    return;
                }

                int studentId = Integer.parseInt(studentIdStr);
                String course = (String)cmbCourse.getSelectedItem();
                int courseId = extractCourseId(course);

                double grade = gradeDAO.getGrade(studentId, courseId);

                JOptionPane.showMessageDialog(this, "Grade : " + String.format("%.2f", grade));

            }catch(NumberFormatException ex){
                JOptionPane.showMessageDialog(this, "Invalid Student ID");
            }catch(Exception ex){
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        return p;
    }

    // ================= MONITOR PROGRESS =================

    private JPanel buildProgressMonitoringPanel(){

        JPanel p = new JPanel(new BorderLayout());
        p.setBorder(BorderFactory.createTitledBorder("Monitor Student Progress"));

        JPanel top = new JPanel(new GridLayout(2, 2, 6, 6));
        top.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JComboBox<String> cmbCourse = new JComboBox<>();
        JComboBox<String> cmbStudent = new JComboBox<>();

        JButton btnViewProgress = new JButton("View Student Progress");

        top.add(new JLabel("Select Course:"));
        top.add(cmbCourse);

        top.add(new JLabel("Select Student:"));
        top.add(cmbStudent);

        p.add(top, BorderLayout.NORTH);

        DefaultListModel<String> model = new DefaultListModel<>();
        JList<String> list = new JList<>(model);
        list.setFont(new Font("Arial", Font.PLAIN, 12));

        JScrollPane scrollPane = new JScrollPane(list);
        scrollPane.setPreferredSize(new Dimension(400, 300));

        p.add(scrollPane, BorderLayout.CENTER);

        JPanel bottom = new JPanel();
        bottom.add(btnViewProgress);
        p.add(bottom, BorderLayout.SOUTH);

        // Load courses
        List<String> courses = allocDAO.listCoursesByFaculty(faculty.getId());
        
        if(courses != null && !courses.isEmpty()) {
            for(String c : courses){
                cmbCourse.addItem(c);
            }
        } else {
            cmbCourse.addItem("No courses assigned");
            cmbCourse.setEnabled(false);
            cmbStudent.setEnabled(false);
            btnViewProgress.setEnabled(false);
        }

        cmbCourse.addActionListener(e -> {
            cmbStudent.removeAllItems();
            String selectedCourse = (String)cmbCourse.getSelectedItem();
            if(selectedCourse != null){
                try {
                    int courseId = extractCourseId(selectedCourse);
                    List<String> students = getStudentsByCourse(courseId);
                    
                    if(students.isEmpty()) {
                        cmbStudent.addItem("No students enrolled");
                    } else {
                        for(String s : students){
                            cmbStudent.addItem(s);
                        }
                    }
                } catch(Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        btnViewProgress.addActionListener(e -> {

            String selectedCourse = (String)cmbCourse.getSelectedItem();
            String selectedStudent = (String)cmbStudent.getSelectedItem();

            if(selectedCourse == null || selectedStudent == null || selectedStudent.equals("No students enrolled")){
                JOptionPane.showMessageDialog(this, "Please select course and student");
                return;
            }

            try {
                int courseId = extractCourseId(selectedCourse);
                int studentId = Integer.parseInt(selectedStudent.split(" - ")[0].trim());

                refreshStudentProgress(model, studentId, courseId);
            } catch(Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        // Initial load
        if(cmbCourse.getItemCount() > 0) {
            cmbCourse.setSelectedIndex(0);
        }

        return p;
    }

    private List<String> getStudentsByCourse(int courseId){
        List<String> students = new ArrayList<>();
        String sql = "SELECT u.id, u.username FROM users u JOIN student_courses sc ON u.id = sc.student_id WHERE sc.course_id = ?";

        try(Connection c = DBConnection.getConnection();
            PreparedStatement ps = c.prepareStatement(sql)){
            ps.setInt(1, courseId);
            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                students.add(rs.getInt("id") + " - " + rs.getString("username"));
            }
        } catch(Exception e){
            e.printStackTrace();
        }
        return students;
    }   

    private void refreshStudentProgress(DefaultListModel<String> model, int studentId, int courseId){

        model.clear();

        // Get overall progress
        double overall = progressDAO.getOverallCourseProgress(studentId, courseId);
        model.addElement("Overall Progress: " + String.format("%.2f", overall) + "%");
        model.addElement("");

        // Get module progress
        List<Map<String,Object>> modules = progressDAO.getModuleProgress(studentId, courseId);
        if(modules != null && !modules.isEmpty()) {
            model.addElement("-- Module Progress --");
            for(Map<String,Object> m : modules){
                model.addElement("  Module: " + m.get("module_name") + " | Status: " + m.get("status") + " | Progress: " + m.get("progress_percentage") + "%");
            }
        }
        model.addElement("");

        // Get study plan tasks
        List<Map<String,Object>> tasks = studyPlanDAO.getStudentTasks(studentId, courseId);
        if(tasks != null && !tasks.isEmpty()) {
            model.addElement("-- Study Plan Tasks --");
            for(Map<String,Object> t : tasks){
                String status = (Boolean)t.get("completed") ? "[✓]" : "[ ]";
                model.addElement("  " + status + " " + t.get("task_description") + " (Due: " + t.get("due_date") + ")");
            }
        }
    }

    // ================= FLAGGING =================

    private JPanel buildFlagPanel(){

        JPanel p = new JPanel(new BorderLayout());
        p.setBorder(BorderFactory.createTitledBorder("Flag Student Progress"));

        JPanel top = new JPanel(new GridLayout(4, 2, 6, 6));
        top.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JComboBox<String> cmbCourse = new JComboBox<>();
        JTextField txtStudentId = new JTextField();

        JComboBox<String> cmbType =
                new JComboBox<>(new String[]{
                        "ATTENDANCE",
                        "PERFORMANCE",
                        "BEHAVIOR"
                });

        JTextField txtDesc = new JTextField();

        JButton btnFlag = new JButton("Create Flag");

        top.add(new JLabel("Select Course:"));
        top.add(cmbCourse);

        top.add(new JLabel("Student ID:"));
        top.add(txtStudentId);

        top.add(new JLabel("Flag Type:"));
        top.add(cmbType);

        top.add(new JLabel("Description:"));
        top.add(txtDesc);

        p.add(top, BorderLayout.NORTH);

        JPanel bottom = new JPanel();
        bottom.add(btnFlag);

        p.add(bottom, BorderLayout.SOUTH);

        List<String> courses = allocDAO.listCoursesByFaculty(faculty.getId());

        if(courses != null && !courses.isEmpty()) {
            for(String c : courses){
                cmbCourse.addItem(c);
            }
        } else {
            cmbCourse.addItem("No courses assigned");
            cmbCourse.setEnabled(false);
            txtStudentId.setEnabled(false);
            txtDesc.setEnabled(false);
            cmbType.setEnabled(false);
            btnFlag.setEnabled(false);
        }

        btnFlag.addActionListener(e -> {

            try{
                String studentIdStr = txtStudentId.getText().trim();
                if(studentIdStr.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Please enter Student ID");
                    return;
                }

                int studentId = Integer.parseInt(studentIdStr);
                String course = (String)cmbCourse.getSelectedItem();
                int courseId = extractCourseId(course);

                String type = (String)cmbType.getSelectedItem();
                String desc = txtDesc.getText().trim();

                if(desc.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Please enter description");
                    return;
                }

                boolean ok = flagDAO.createFlag(courseId, studentId, type, desc);

                if(ok){
                    JOptionPane.showMessageDialog(this, "Flag created successfully");
                    txtStudentId.setText("");
                    txtDesc.setText("");
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to create flag");
                }

            }catch(NumberFormatException ex){
                JOptionPane.showMessageDialog(this, "Invalid Student ID");
            }catch(Exception ex){
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }

        });

        return p;
    }
    
}
