package com.example.project.ui;

import com.example.project.dao.*;
import com.example.project.model.User;

import javax.swing.*;
import java.awt.*;
import java.sql.Date;
import java.util.List;
import java.util.Map;


public class StudentDashboardFrame extends JFrame {

    private User student;

    private AllocationDAO allocDAO = new AllocationDAO();
    private StudyPlanDAO studyPlanDAO = new StudyPlanDAO();
    private ProgressTrackingDAO progressDAO = new ProgressTrackingDAO();
    private TopicDAO topicDAO = new TopicDAO();
    private FlagDAO flagDAO = new FlagDAO();

    public StudentDashboardFrame(User student) {

        this.student = student;

        setTitle("Student Dashboard - " + student.getUsername());
        setSize(1200, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JTabbedPane tabs = new JTabbedPane();

        tabs.addTab("My Courses", buildCoursesPanel());
        tabs.addTab("Study Planner", buildStudyPlannerPanel());
        tabs.addTab("Progress Tracking", buildProgressPanel());
        tabs.addTab("Topics", buildTopicsPanel());
        add(tabs, BorderLayout.CENTER);

        setVisible(true);

        // FLAG ALERT
        List<Map<String,Object>> flags = flagDAO.getFlagsByStudent(student.getId());

        if(flags != null && flags.size() > 0){
            StringBuilder flagMsg = new StringBuilder("⚠ You have academic flags:\n\n");
            for(Map<String,Object> f : flags) {
                flagMsg.append("Type: ").append(f.get("flag_type"))
                       .append("\nDescription: ").append(f.get("description"))
                       .append("\n\n");
            }
            flagMsg.append("Please contact faculty.");
            JOptionPane.showMessageDialog(this, flagMsg.toString(), "Academic Flags", JOptionPane.WARNING_MESSAGE);
        }
    }

    // ================= COURSES =================

    private JPanel buildCoursesPanel(){

        JPanel p = new JPanel(new BorderLayout());
        p.setBorder(BorderFactory.createTitledBorder("Enrolled Courses"));

        DefaultListModel<String> model = new DefaultListModel<>();
        JList<String> list = new JList<>(model);
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.setFont(new Font("Arial", Font.PLAIN, 14));

        JScrollPane scrollPane = new JScrollPane(list);
        scrollPane.setPreferredSize(new Dimension(400, 300));

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(new JLabel("Your Enrolled Courses:"), BorderLayout.WEST);
        
        JButton btnRefresh = new JButton("Refresh");
        btnRefresh.addActionListener(e -> refreshCourses(model));
        topPanel.add(btnRefresh, BorderLayout.EAST);

        p.add(topPanel, BorderLayout.NORTH);
        p.add(scrollPane, BorderLayout.CENTER);

        refreshCourses(model);

        return p;
    }

    private void refreshCourses(DefaultListModel<String> model){

        model.clear();

        List<String> courses = allocDAO.listCoursesByStudent(student.getId());

        if(courses == null || courses.isEmpty()) {
            model.addElement("No courses enrolled");
        } else {
            for(String c : courses){
                model.addElement(c);
            }
        }
    }

    // ================= STUDY PLANNER =================

    private JPanel buildStudyPlannerPanel(){

        JPanel p = new JPanel(new BorderLayout());
        p.setBorder(BorderFactory.createTitledBorder("Study Plan Manager"));

        JPanel top = new JPanel(new GridLayout(4, 2, 6, 6));
        top.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JComboBox<String> cmbCourse = new JComboBox<>();
        JTextField txtTask = new JTextField();
        JTextField txtDueDate = new JTextField("YYYY-MM-DD");

        JComboBox<String> cmbPriority =
                new JComboBox<>(new String[]{"LOW","MEDIUM","HIGH"});

        JButton btnAdd = new JButton("Add Task");

        top.add(new JLabel("Select Course:"));
        top.add(cmbCourse);

        top.add(new JLabel("Task Description:"));
        top.add(txtTask);

        top.add(new JLabel("Due Date:"));
        top.add(txtDueDate);

        top.add(new JLabel("Priority:"));
        top.add(cmbPriority);

        p.add(top, BorderLayout.NORTH);

        DefaultListModel<String> model = new DefaultListModel<>();
        JList<String> list = new JList<>(model);
        list.setFont(new Font("Arial", Font.PLAIN, 12));

        JScrollPane scrollPane = new JScrollPane(list);
        scrollPane.setPreferredSize(new Dimension(400, 300));

        p.add(scrollPane, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel();

        JButton btnRefresh = new JButton("Refresh");

        bottomPanel.add(btnAdd);
        bottomPanel.add(btnRefresh);

        p.add(bottomPanel, BorderLayout.SOUTH);

        // LOAD COURSES
        List<String> courses = allocDAO.listCoursesByStudent(student.getId());

        if(courses != null && !courses.isEmpty()) {
            for(String c : courses){
                cmbCourse.addItem(c);
            }
        } else {
            cmbCourse.addItem("No courses enrolled");
            cmbCourse.setEnabled(false);
            txtTask.setEnabled(false);
            txtDueDate.setEnabled(false);
            cmbPriority.setEnabled(false);
            btnAdd.setEnabled(false);
        }

        btnAdd.addActionListener(e -> {

            String task = txtTask.getText().trim();
            String dueStr = txtDueDate.getText().trim();
            String priority = (String)cmbPriority.getSelectedItem();

            if(task.isEmpty()){
                JOptionPane.showMessageDialog(this,"Please enter task description");
                return;
            }

            try{

                Date due = Date.valueOf(dueStr);

                String course = (String)cmbCourse.getSelectedItem();

                int courseId = extractCourseId(course);

                boolean ok = studyPlanDAO.addTask(student.getId(),
                                courseId,
                                task,
                                due,
                                priority);

                if(ok){
                    JOptionPane.showMessageDialog(this,"Task added successfully");
                    txtTask.setText("");
                    txtDueDate.setText("YYYY-MM-DD");
                    refreshStudyPlan(model, courseId);
                } else {
                    JOptionPane.showMessageDialog(this,"Failed to add task");
                }

            }catch(IllegalArgumentException ex){
                JOptionPane.showMessageDialog(this,"Invalid date format (use YYYY-MM-DD)");
            }catch(Exception ex){
                JOptionPane.showMessageDialog(this,"Error: " + ex.getMessage());
            }

        });

        btnRefresh.addActionListener(e -> {

            String course = (String)cmbCourse.getSelectedItem();
            
            if(course == null) {
                return;
            }

            int courseId = extractCourseId(course);

            refreshStudyPlan(model, courseId);

        });

        // Initial load
        if(cmbCourse.getItemCount() > 0) {
            cmbCourse.setSelectedIndex(0);
            String course = (String)cmbCourse.getSelectedItem();
            if(course != null) {
                int courseId = extractCourseId(course);
                refreshStudyPlan(model, courseId);
            }
        }

        return p;
    }

    private void refreshStudyPlan(DefaultListModel<String> model, int courseId){

        model.clear();

        List<Map<String,Object>> tasks =
                studyPlanDAO.getStudentTasks(student.getId(), courseId);

        if(tasks == null || tasks.isEmpty()) {
            model.addElement("No tasks for this course");
        } else {
            for(Map<String,Object> t : tasks){

                String status =
                        (Boolean)t.get("completed") ? "[✓]" : "[ ]";

                model.addElement(
                        status + " " + t.get("description")
                                + " (Due: " + t.get("dueDate") + ")"
                );
            }
        }
    }

    // ================= PROGRESS =================

    private JPanel buildProgressPanel(){

        JPanel p = new JPanel(new BorderLayout());
        p.setBorder(BorderFactory.createTitledBorder("Progress Tracking"));

        JPanel top = new JPanel(new GridLayout(3, 2, 6, 6));
        top.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JComboBox<String> cmbCourse = new JComboBox<>();
        JTextField txtModule = new JTextField();

        JComboBox<String> cmbStatus =
                new JComboBox<>(new String[]{
                        "NOT_STARTED",
                        "IN_PROGRESS",
                        "COMPLETED"
                });

        JSpinner progress =
                new JSpinner(new SpinnerNumberModel(0, 0, 100, 10));

        JButton btnUpdate = new JButton("Update Progress");

        top.add(new JLabel("Select Course:"));
        top.add(cmbCourse);

        top.add(new JLabel("Module Name:"));
        top.add(txtModule);

        top.add(new JLabel("Status:"));
        top.add(cmbStatus);

        p.add(top, BorderLayout.NORTH);

        DefaultListModel<String> model = new DefaultListModel<>();
        JList<String> list = new JList<>(model);
        list.setFont(new Font("Arial", Font.PLAIN, 12));

        JScrollPane scrollPane = new JScrollPane(list);
        scrollPane.setPreferredSize(new Dimension(400, 300));

        p.add(scrollPane, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel();

        bottomPanel.add(new JLabel("Progress %:"));
        bottomPanel.add(progress);
        bottomPanel.add(btnUpdate);

        JButton btnRefresh = new JButton("Refresh");
        bottomPanel.add(btnRefresh);

        p.add(bottomPanel, BorderLayout.SOUTH);

        // LOAD COURSES
        List<String> courses = allocDAO.listCoursesByStudent(student.getId());

        if(courses != null && !courses.isEmpty()) {
            for(String c : courses){
                cmbCourse.addItem(c);
            }
        } else {
            cmbCourse.addItem("No courses enrolled");
            cmbCourse.setEnabled(false);
            txtModule.setEnabled(false);
            cmbStatus.setEnabled(false);
            progress.setEnabled(false);
            btnUpdate.setEnabled(false);
        }

        btnUpdate.addActionListener(e -> {

            String module = txtModule.getText().trim();
            int percent = (Integer)progress.getValue();
            String status = (String)cmbStatus.getSelectedItem();
            String course = (String)cmbCourse.getSelectedItem();

            if(module.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter module name");
                return;
            }

            if(course == null) {
                return;
            }

            try {
                int courseId = extractCourseId(course);

                boolean ok = progressDAO.updateModuleProgress(
                        student.getId(),
                        courseId,
                        module,
                        status,
                        percent
                );

                if(ok){
                    JOptionPane.showMessageDialog(this,"Progress updated successfully");
                    txtModule.setText("");
                    refreshProgress(model, courseId);
                } else {
                    JOptionPane.showMessageDialog(this,"Failed to update progress");
                }
            } catch(Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }

        });

        btnRefresh.addActionListener(e -> {

            String course = (String)cmbCourse.getSelectedItem();

            if(course == null) {
                return;
            }

            int courseId = extractCourseId(course);

            refreshProgress(model, courseId);

        });

        // Initial load
        if(cmbCourse.getItemCount() > 0) {
            cmbCourse.setSelectedIndex(0);
            String course = (String)cmbCourse.getSelectedItem();
            if(course != null) {
                int courseId = extractCourseId(course);
                refreshProgress(model, courseId);
            }
        }

        return p;
    }

    private void refreshProgress(DefaultListModel<String> model, int courseId){

        model.clear();

        List<Map<String,Object>> modules =
                progressDAO.getModuleProgress(student.getId(), courseId);

        double overall =
                progressDAO.getOverallCourseProgress(student.getId(), courseId);

        model.addElement("Overall Progress: " + String.format("%.2f", overall) + "%");
        model.addElement("");

        if(modules == null || modules.isEmpty()) {
            model.addElement("No module progress recorded");
        } else {
            model.addElement("-- Module Progress --");
            for(Map<String,Object> m : modules){

                model.addElement(
                        "  Module: " + m.get("name")
                                + " | Status: " + m.get("status")
                                + " | Progress: " + m.get("percentage") + "%"
                );
            }
        }
    }

    // ================= TOPICS =================

    private JPanel buildTopicsPanel(){

        JPanel p = new JPanel(new BorderLayout());
        p.setBorder(BorderFactory.createTitledBorder("Course Topics"));

        DefaultListModel<String> model = new DefaultListModel<>();
        JList<String> list = new JList<>(model);
        list.setFont(new Font("Arial", Font.PLAIN, 12));
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(list);
        scrollPane.setPreferredSize(new Dimension(400, 300));

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(new JLabel("Topics for Your Courses:"), BorderLayout.WEST);
        
        JButton btnRefresh = new JButton("Refresh");
        btnRefresh.addActionListener(e -> refreshTopics(model));
        topPanel.add(btnRefresh, BorderLayout.EAST);

        p.add(topPanel, BorderLayout.NORTH);
        p.add(scrollPane, BorderLayout.CENTER);

        refreshTopics(model);

        return p;
    }

    private void refreshTopics(DefaultListModel<String> model){

        model.clear();

        List<String> courses = allocDAO.listCoursesByStudent(student.getId());

        if(courses == null || courses.isEmpty()) {
            model.addElement("No courses enrolled");
            return;
        }

        for(String courseStr : courses){

            model.addElement("--- " + courseStr + " ---");

            try {
                // Extract course ID from the string format "ID - Name"
                int courseId = extractCourseId(courseStr);

                List<Map<String,Object>> topics = topicDAO.getTopicsByCourse(courseId);

                if(topics == null || topics.isEmpty()) {
                    model.addElement("   (No topics added)");
                } else {
                    for(Map<String,Object> t : topics){
                        String name = (String)t.get("name");
                        String desc = (String)t.get("description");
                        model.addElement("   • " + name + ": " + desc);
                    }
                }
            } catch(Exception ex) {
                model.addElement("   (Error loading topics)");
                ex.printStackTrace();
            }

            model.addElement("");
        }
    }

    private int extractCourseId(String courseStr) {
        return Integer.parseInt(courseStr.split(" - ")[0].trim());
    }
}