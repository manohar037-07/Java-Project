package com.example.project;

import java.sql.Connection;
import java.sql.Statement;

public class AlterStudyPlansAddCompleted {
    public static void main(String[] args) {
        try (Connection c = DBConnection.getConnection(); Statement s = c.createStatement()) {
            s.executeUpdate("ALTER TABLE study_plans ADD COLUMN completed BOOLEAN NOT NULL DEFAULT FALSE");
            System.out.println("Added completed column successfully");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}