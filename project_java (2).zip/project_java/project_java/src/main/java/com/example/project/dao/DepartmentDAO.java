package com.example.project.dao;

import com.example.project.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class DepartmentDAO {

    public boolean createDepartment(String name) {
        // 'name' badulu 'dept_name' undali
        String sql = "INSERT INTO departments (dept_name) VALUES (?)";
        try (Connection c = DBConnection.getConnection(); 
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, name);
            return ps.executeUpdate() == 1;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<String> listDepartments() {
        List<String> list = new ArrayList<>();
        // 'dept_name' select cheyyali
        String sql = "SELECT dept_name FROM departments";
        try (Connection c = DBConnection.getConnection(); 
             PreparedStatement ps = c.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(rs.getString("dept_name"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public boolean deleteDepartment(String name) {
        try (Connection con = DBConnection.getConnection()) {
            // 'dept_name' match cheyyali
            String sql = "DELETE FROM departments WHERE dept_name=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, name);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}