# Build and Run Student Management System
Set-Location "c:\Users\Jaswa\OneDrive\Desktop\project_java"
$JAVAC = "C:\Program Files\Java\jdk-17\bin\javac.exe"
$JAVA = "C:\Program Files\Common Files\Oracle\Java\javapath\java.exe"

echo "=== Building Student Management System ==="

# Create directories
mkdir -Force build\classes | Out-Null
mkdir -Force build\resources | Out-Null
mkdir -Force lib | Out-Null

# Copy resources
Copy-Item src\main\resources\*.properties build\resources\ -Force

echo "Downloading MySQL connector..."
$client = New-Object System.Net.WebClient
$url = "https://dev.mysql.com/get/Downloads/Connector-J/mysql-connector-java-8.0.33.jar"
$dest = "lib\mysql-connector-java-8.0.33.jar"
try {
  if (-not (Test-Path $dest)) {
    $client.DownloadFile($url, $dest)
  }
  echo "MySQL JARavailable"
} catch {
  echo "Could not download MySQL driver"
}

echo "Compiling Java code..."
& $JAVAC -d build\classes -cp "lib\mysql-connector-java-8.0.33.jar" `
  src\main\java\com\example\project\DBConnection.java `
  src\main\java\com\example\project\Main.java `
  src\main\java\com\example\project\model\User.java `
  src\main\java\com\example\project\dao\*.java `
  src\main\java\com\example\project\ui\*.java

if ($? -eq $false) {
  echo "Compilation failed!"
  exit 1
}

echo "Launching application..."
& $JAVA -cp "build\classes;build\resources;lib\mysql-connector-java-8.0.33.jar" com.example.project.Main
