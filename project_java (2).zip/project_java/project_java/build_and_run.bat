@echo off
REM Build and run Student Management System
cd /d "%~dp0"

REM Set variables
set JAVA_HOME=C:\Program Files\Java\jdk-17.0.12
set SRC_DIR=src\main\java
set OUT_DIR=build\classes
set RESOURCES_DIR=src\main\resources

REM Create build directory
if not exist "%OUT_DIR%" mkdir "%OUT_DIR%"

REM Copy resources
if not exist "build\resources" mkdir "build\resources"
copy "%RESOURCES_DIR%\*.properties" "build\resources\"

REM Download MySQL connector if not exists
if not exist "lib" mkdir "lib"
if not exist "lib\mysql-connector-java-8.0.33.jar" (
    echo Downloading MySQL connector...
    powershell -Command "(New-Object System.Net.WebClient).DownloadFile('https://dev.mysql.com/get/Downloads/Connector-J/mysql-connector-java-8.0.33.jar', 'lib\mysql-connector-java-8.0.33.jar')"
)

REM Compile Java sources
echo Compiling Java sources...
"%JAVA_HOME%\bin\javac" -d "%OUT_DIR%" -cp "lib\mysql-connector-java-8.0.33.jar" ^
  "%SRC_DIR%\com\example\project\*.java" ^
  "%SRC_DIR%\com\example\project\model\*.java" ^
  "%SRC_DIR%\com\example\project\dao\*.java" ^
  "%SRC_DIR%\com\example\project\ui\*.java"

if %errorlevel% neq 0 (
    echo Compilation failed!
    exit /b 1
)

echo Compilation successful!

REM Run the application
echo Starting Student Management System...
"%JAVA_HOME%\bin\java" -cp "%OUT_DIR%;build\resources;lib\mysql-connector-java-8.0.33.jar" com.example.project.Main

pause
