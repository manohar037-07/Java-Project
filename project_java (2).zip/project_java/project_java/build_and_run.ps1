$ErrorActionPreference = "Stop"

# Configuration
$JAVA_EXE = "C:\Program Files\Java\jdk-17.0.12\bin\java.exe"
$JAVAC_EXE = "C:\Program Files\Java\jdk-17.0.12\bin\javac.exe"
$PROJECT_DIR = Get-Location
$SRC_DIR = "$PROJECT_DIR\src\main\java"
$OUT_DIR = "$PROJECT_DIR\build\classes"
$RESOURCES_DIR = "$PROJECT_DIR\src\main\resources"
$LIB_DIR = "$PROJECT_DIR\lib"

Write-Host "=====================================" -ForegroundColor Cyan
Write-Host "Student Management System - Build & Run" -ForegroundColor Cyan
Write-Host "=====================================" -ForegroundColor Cyan

# Create directories
Write-Host "`n[1/5] Creating directories..." -ForegroundColor Yellow
New-Item -ItemType Directory -Force -Path "$OUT_DIR" | Out-Null
New-Item -ItemType Directory -Force -Path "$LIB_DIR" | Out-Null
New-Item -ItemType Directory -Force -Path "$PROJECT_DIR\build\resources" | Out-Null

# Copy resources
Write-Host "[2/5] Copying resources..." -ForegroundColor Yellow
Copy-Item "$RESOURCES_DIR\*.properties" "$PROJECT_DIR\build\resources\" -Force

# Download MySQL Connector
Write-Host "[3/5] Checking MySQL connector..." -ForegroundColor Yellow
$MYSQL_JAR = "$LIB_DIR\mysql-connector-java-8.0.33.jar"
if (-not (Test-Path $MYSQL_JAR)) {
    Write-Host "  Downloading MySQL connector... (this may take a moment)" -ForegroundColor Cyan
    try {
        $url = "https://dev.mysql.com/get/Downloads/Connector-J/mysql-connector-java-8.0.33.jar"
        (New-Object System.Net.WebClient).DownloadFile($url, $MYSQL_JAR)
        Write-Host "  ✓ MySQL connector downloaded" -ForegroundColor Green
    }
    catch {
        Write-Host "  ⚠ Failed to download MySQL connector. Make sure MySQL JDBC jar is in lib/ folder" -ForegroundColor Yellow
    }
}

# Compile
Write-Host "[4/5] Compiling Java sources..." -ForegroundColor Yellow
$cp = if (Test-Path $MYSQL_JAR) { "$MYSQL_JAR" } else { "." }

$files = @(
    "$SRC_DIR\com\example\project\DBConnection.java",
    "$SRC_DIR\com\example\project\Main.java",
    "$SRC_DIR\com\example\project\model\User.java",
    "$SRC_DIR\com\example\project\dao\*.java",
    "$SRC_DIR\com\example\project\ui\*.java"
)

Write-Host "  Classpath: $cp"
& $JAVAC_EXE -d "$OUT_DIR" -cp "$cp" $files 2>&1

if ($LASTEXITCODE -ne 0) {
    Write-Host "✗ Compilation failed!" -ForegroundColor Red
    exit 1
}
Write-Host "  ✓ Compilation successful" -ForegroundColor Green

# Run
Write-Host "[5/5] Launching application..." -ForegroundColor Yellow
$cp_run = if (Test-Path $MYSQL_JAR) { "$OUT_DIR;$PROJECT_DIR\build\resources;$MYSQL_JAR" } else { "$OUT_DIR;$PROJECT_DIR\build\resources" }

Write-Host "`n  Classpath: $cp_run" -ForegroundColor Gray
Write-Host "`n  Starting Application...`n" -ForegroundColor Cyan

& $JAVA_EXE -cp "$cp_run" com.example.project.Main

Write-Host "`nApplication closed." -ForegroundColor Yellow
