# Student Management (Swing + MySQL)

Quick-start:

1. Install MySQL and create a user. Update `src/main/resources/db.properties` with credentials.
2. Run SQL scripts in `sql/schema.sql` and `sql/data.sql` to create the `schooldb` database and seed users.

Commands (Windows, with Maven installed):

```bash
mvn package
java -cp target/student-management-1.0-SNAPSHOT.jar;path\to\mysql-connector-java-8.0.33.jar com.example.project.Main
```

## Features Overview

### **Admin Dashboard**
- User Management: Create faculty and student accounts
- Department & Course Management: Add departments and courses
- Allocation Management: Assign courses to faculty and students

### **Faculty Dashboard**
- **Syllabus Management**: Add topics with descriptions to courses
- **Student Tracking**: Monitor attendance and grades
- **Class Analytics**: Record class sessions and view attendance trends
- **Flagging System**: Create and track performance/attendance/behavior flags

### **Student Dashboard**
- **My Courses**: View enrolled courses
- **Study Planner**: 
  - Add tasks with due dates and priority (LOW/MEDIUM/HIGH)
  - Mark tasks as completed
  - Track pending assignments
- **Progress Tracking**:
  - Track module status (NOT_STARTED, IN_PROGRESS, COMPLETED)
  - View progress percentage for each module
  - Overall course progress calculation

## Test Login Credentials

- **Admin**: `admin` / `admin123`
- **Faculty**: `faculty1` / `fac123`
- **Student**: `student1` / `stud123`

## Database Schema

Tables:
- `users` - Authentication and role management
- `courses`, `departments`, `subjects` - Course structure
- `faculty_courses`, `student_courses` - Allocations
- `topics` - Syllabus management
- `attendance`, `grades` - Student performance
- `class_sessions` - Class tracking
- `flags` - Performance/behavior alerts
- `study_plans` - Student to-do lists
- `progress_tracking` - Module completion tracking

## Architecture

- **UI**: Swing-based GUI with role-specific dashboards
- **DAO**: Data access objects for each entity
- **DB**: MySQL with property-based connection config
- **Entry Point**: `com.example.project.Main`

## Notes

- Passwords stored in plain text for demo only. Use hashing in production.
- Course IDs currently hardcoded in UI (1 for demos). Update for multi-course support.
- Task ID tracking in Study Planner needs production enhancement.

Next steps:
- Implement password hashing (BCrypt)
- Add multi-course support in UI
- Create analytics/reports module
- Add email notifications
