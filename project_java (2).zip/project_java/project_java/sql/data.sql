USE schooldb;

-- Seed admin (only one), a faculty and a student
INSERT INTO users (username, password, role) VALUES
('admin', 'admin123', 'ADMIN'),
('faculty1', 'fac123', 'FACULTY'),
('student1', 'stud123', 'STUDENT');

-- Seed departments, subjects, courses
INSERT INTO departments (name) VALUES ('Computer Science'), ('Mathematics');

INSERT INTO subjects (name, department_id) VALUES
('Data Structures', 1),
('Algorithms', 1),
('Calculus', 2);

INSERT INTO courses (name, subject_id) VALUES
('DS - Section A', 1),
('Algorithms - Section A', 2),
('Calculus - Section A', 3);

-- Assign faculty and student to courses
-- faculty1 is id=2, student1 is id=3 based on seed above; adjust if needed
INSERT INTO faculty_courses (faculty_id, course_id) VALUES (2, 1), (2, 2);
INSERT INTO student_courses (student_id, course_id) VALUES (3, 1);

-- Seed topics/syllabus for courses
INSERT INTO topics (course_id, topic_name, description) VALUES
(1, 'Introduction to Arrays', 'Basic array concepts and operations'),
(1, 'Linked Lists', 'Singly and doubly linked lists'),
(1, 'Stacks and Queues', 'LIFO and FIFO data structures'),
(2, 'Sorting Algorithms', 'Bubble, merge, quick sort'),
(2, 'Graph Algorithms', 'BFS, DFS, Dijkstra');

-- Seed attendance data
INSERT INTO attendance (student_id, course_id, attendance_date, is_present) VALUES
(3, 1, '2026-02-28', TRUE),
(3, 1, '2026-03-01', TRUE),
(3, 1, '2026-03-02', FALSE);

-- Seed grades
INSERT INTO grades (student_id, course_id, grade) VALUES
(3, 1, 85.50);

-- Seed class sessions
INSERT INTO class_sessions (course_id, session_date, topic_covered, total_students) VALUES
(1, '2026-02-28', 'Introduction to Arrays', 30),
(1, '2026-03-01', 'Linked Lists', 28);

-- Seed flags (examples)
INSERT INTO flags (course_id, student_id, flag_type, description, resolved) VALUES
(1, 3, 'ATTENDANCE', 'Missed class on 2026-03-02', FALSE);

-- Seed study plans for student1 (id=3)
INSERT INTO study_plans (student_id, course_id, task_description, due_date, priority, completed) VALUES
(3, 1, 'Complete Chapter 1 - Arrays', '2026-03-05', 'HIGH', FALSE),
(3, 1, 'Practice linked list problems', '2026-03-10', 'MEDIUM', FALSE),
(3, 1, 'Review Stacks and Queues', '2026-03-15', 'MEDIUM', FALSE);

-- Seed progress tracking for student1
INSERT INTO progress_tracking (student_id, course_id, module_name, status, progress_percentage) VALUES
(3, 1, 'Array Fundamentals', 'IN_PROGRESS', 60),
(3, 1, 'Linked Lists', 'NOT_STARTED', 0),
(3, 1, 'Stacks & Queues', 'NOT_STARTED', 0);
