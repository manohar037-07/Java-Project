@echo off
REM Run the compiled Student Management System
cd /d "%~dp0"

set CLASSPATH=build\classes;build\resources
set JAVA=C:\Program Files\Common Files\Oracle\Java\javapath\java.exe

echo.
echo ======================================
echo Student Management System
echo ======================================
echo.
echo Starting application...
echo.

"%JAVA%" -cp "%CLASSPATH%" com.example.project.Main

pause
